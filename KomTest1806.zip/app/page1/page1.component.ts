import { Component, ElementRef, ViewChild, OnInit, SimpleChanges, DoCheck } from '@angular/core';
import * as d3 from 'd3';
import {style} from '@angular/animations';
import { svg } from 'd3';


@Component({
  selector: 'app-page1',
  templateUrl: './page1.component.html',
  styleUrls: ['./page1.component.css']
})
export class Page1Component implements OnInit, DoCheck{

  ngOnInit(){
    // console.log('page1 works');


    // this.level = parseInt((<HTMLInputElement>document.getElementById('slider')).value);
    // console.log(this.level);
    // (<HTMLInputElement>document.getElementById('slider')).onchange = this.ngAfterContentInit;
    
   
    // this.svg.selectAll('ellipse').remove();
    // this.svg.selectAll('path').remove();
    // this.svg.selectAll('text').remove();
  }

  title = 'KomTest';

  @ViewChild('graphContainer') graphContainer: ElementRef;

  width = 1240;
  height = 570;
  k = 1;
  colors = d3.scaleOrdinal(d3.schemeCategory10);
  clickOnNode = false;
  svg: any;
  circle: any;
  path: any;
  centered: any;
  centerx: any;
  centery: any;
  glossary: any;
  linkword: any;
  gText: any;
  gImage: any;
  circle1: any;
 


  level = 1;
  selectedNode = null;
  selectedLink = null;
  mousedownLink = null;
  mousedownNode = null;
  mouseupNode = null;

  // store the nodes
  nodes = [
    { id: 0, text: 'computer science', x: 300, y: 70, reflexive: true },
    { id: 1, text: 'algorithm', x: 210, y: 140, reflexive: true },
    { id: 2, text: 'programming', x: 350, y: 160, reflexive: true },
    { id: 3, text: 'problem solving', x: 120, y: 210, reflexive: true },
    { id: 4, text: 'low-level language', x: 270, y: 230, reflexive: true },
    { id: 5, text: 'high-level language', x: 410, y: 230, reflexive: true },
    { id: 6, text: 'debugging', x: 480, y: 210, reflexive: true },
    { id: 7, text: 'machine code', x: 230, y: 300, reflexive: false },
    { id: 8, text: 'source code', x: 420, y: 300, reflexive: false },
    { id: 9, text: 'bug', x: 550, y: 260, reflexive: false },
    { id: 10, text: 'logic error', x: 510, y: 320, reflexive: false },
    { id: 11, text: 'compile-time error', x: 670, y: 320, reflexive: false },
    { id: 12, text: 'run-time error', x: 590, y: 320, reflexive: false },
    { id: 13, text: 'intepreter', x: 340, y: 360, reflexive: false },
    { id: 14, text: 'compiler', x: 480, y: 360, reflexive: false },
  ];

   // store the link words
   linkwords = [
     {id: 0, text: 'is science of', x: 255, y: 105, reflexive: false},
     {id: 1, text: 'for', x: 165, y: 175, reflexive: false},
     {id: 2, text: 'is about', x: 328, y: 120, reflexive: false},
     {id: 3, text: 'has', x: 350, y: 195, reflexive: false},
     {id: 4, text: 'uses', x: 415, y: 185, reflexive: false},
     {id: 5, text: 'is called', x: 250, y: 265, reflexive: false},
     {id: 6, text: 'is called', x: 415, y: 265, reflexive: false},
     {id: 7, text: 'to find', x: 515, y: 235, reflexive: false},
     {id: 8, text: 'in', x: 485, y: 280, reflexive: false},
     {id: 9, text: 'includes', x: 570, y: 290, reflexive: false},
     {id: 10, text: 'into', x: 285, y: 330, reflexive: false},
     {id: 11, text: 'is translated with', x: 410, y: 335, reflexive: false},
   ];

  // store the links
  links = [
    { source: this.nodes[0], target: this.linkwords[0], left: false, right: false },
    { source: this.linkwords[0], target: this.nodes[1], left: false, right: true },
    { source: this.nodes[1], target: this.linkwords[1], left: false, right: false },
    { source: this.linkwords[1], target: this.nodes[3], left: false, right: true },
    { source: this.nodes[0], target: this.linkwords[2], left: false, right: false },
    { source: this.linkwords[2], target: this.nodes[2], left: false, right: true },
    { source: this.nodes[2], target: this.linkwords[3], left: false, right: false },
    { source: this.linkwords[3], target: this.nodes[4], left: false, right: true },
    { source: this.linkwords[3], target: this.nodes[5], left: false, right: true },
    { source: this.nodes[2], target: this.linkwords[4], left: false, right: false },
    { source: this.linkwords[4], target: this.nodes[6], left: false, right: true },
    { source: this.nodes[4], target: this.linkwords[5], left: false, right: false },
    { source: this.linkwords[5], target: this.nodes[7], left: false, right: true },
    { source: this.nodes[5], target: this.linkwords[6], left: false, right: false },
    { source: this.linkwords[6], target: this.nodes[8], left: false, right: true },
    { source: this.nodes[6], target: this.linkwords[7], left: false, right: false },
    { source: this.linkwords[7], target: this.nodes[9], left: false, right: true },
    { source: this.nodes[9], target: this.linkwords[8], left: false, right: false },
    { source: this.linkwords[8], target: this.nodes[8], left: false, right: true },
    { source: this.nodes[9], target: this.linkwords[9], left: false, right: false },
    { source: this.linkwords[9], target: this.nodes[10], left: false, right: true },
    { source: this.linkwords[9], target: this.nodes[11], left: false, right: true },
    { source: this.linkwords[9], target: this.nodes[12], left: false, right: true },
    { source: this.nodes[13], target: this.linkwords[10], left: false, right: false },
    { source: this.linkwords[10], target: this.nodes[7], left: false, right: true },
    { source: this.nodes[8], target: this.linkwords[11], left: false, right: false },
    { source: this.linkwords[11], target: this.nodes[13], left: false, right: true },
    { source: this.linkwords[11], target: this.nodes[14], left: false, right: true },    
  ];

  // store the white rectangulars as simulation for text fields
  glossaries = [
    { target: this.nodes[0], hidden: true, width: 60, height: 80},
    { target: this.nodes[1], hidden: true, width: 60, height: 80},
    { target: this.nodes[2], hidden: true, width: 60, height: 80},
    { target: this.nodes[3], hidden: true, width: 60, height: 80},
    { target: this.nodes[4], hidden: true, width: 60, height: 80},
    { target: this.nodes[5], hidden: true, width: 60, height: 80},
    { target: this.nodes[6], hidden: true, width: 60, height: 80},
    { target: this.nodes[7], hidden: true, width: 60, height: 80},
    { target: this.nodes[8], hidden: true, width: 60, height: 80},
    { target: this.nodes[9], hidden: true, width: 60, height: 80},
    { target: this.nodes[10], hidden: true, width: 60, height: 80},
    { target: this.nodes[11], hidden: true, width: 60, height: 80},
    { target: this.nodes[12], hidden: true, width: 60, height: 80},
    { target: this.nodes[13], hidden: true, width: 60, height: 80},
    { target: this.nodes[14], hidden: true, width: 60, height: 80},
  ];

  gTexts = [
    {text: 'this is only a text for test, later we will put the glossary here. For now the width will be adjusted automatically according to the size of rectangular.', target: this.nodes[0], hidden: true},
    {text: 'this is only a text for test, later we will put the glossary here. For now the width will be adjusted automatically according to the size of rectangular.', target: this.nodes[1], hidden: true},
    {text: 'this is only a text for test, later we will put the glossary here. For now the width will be adjusted automatically according to the size of rectangular.', target: this.nodes[2], hidden: true},
    {text: 'this is only a text for test, later we will put the glossary here. For now the width will be adjusted automatically according to the size of rectangular.', target: this.nodes[3], hidden: true},
    {text: 'this is only a text for test, later we will put the glossary here. For now the width will be adjusted automatically according to the size of rectangular.', target: this.nodes[4], hidden: true},
    {text: 'this is only a text for test, later we will put the glossary here. For now the width will be adjusted automatically according to the size of rectangular.', target: this.nodes[5], hidden: true},
    {text: 'this is only a text for test, later we will put the glossary here. For now the width will be adjusted automatically according to the size of rectangular.', target: this.nodes[6], hidden: true},
    {text: 'this is only a text for test, later we will put the glossary here. For now the width will be adjusted automatically according to the size of rectangular.', target: this.nodes[7], hidden: true},
    {text: 'this is only a text for test, later we will put the glossary here. For now the width will be adjusted automatically according to the size of rectangular.', target: this.nodes[8], hidden: true},
    {text: 'this is only a text for test, later we will put the glossary here. For now the width will be adjusted automatically according to the size of rectangular.', target: this.nodes[9], hidden: true},
    {text: 'this is only a text for test, later we will put the glossary here. For now the width will be adjusted automatically according to the size of rectangular.', target: this.nodes[10], hidden: true},
    {text: 'this is only a text for test, later we will put the glossary here. For now the width will be adjusted automatically according to the size of rectangular.', target: this.nodes[11], hidden: true},
    {text: 'this is only a text for test, later we will put the glossary here. For now the width will be adjusted automatically according to the size of rectangular.', target: this.nodes[12], hidden: true},
    {text: 'this is only a text for test, later we will put the glossary here. For now the width will be adjusted automatically according to the size of rectangular.', target: this.nodes[13], hidden: true},
    {text: 'this is only a text for test, later we will put the glossary here. For now the width will be adjusted automatically according to the size of rectangular.', target: this.nodes[14], hidden: true},
  ];

  ngDoCheck(){
    // console.log('docheck');
    // this.restart;
  }

  update(level2: string){
    console.log('update');
  }

  ngAfterContentInit() {

    
    // document.getElementById('slider').style.color = 'black';
    
    // (<HTMLInputElement>document.getElementById('slider')).onchange = this.restart;

    


    this.svg = d3.select('#graphContainer')
    .attr('oncontextmenu', 'return false;')
    .attr('width', this.width)
    .attr('height', this.height);

    var logo = this.svg. append('image') . attr('xlink:href', 'assets/icon.jpg') . attr('width', 100) . attr('height', 100);



  // arrow styles
    this.svg.append('svg:defs').append('svg:marker')
    .attr('id', 'end-arrow')
    .attr('viewBox', '0 -5 10 10')
    .attr('refX', 6)
    .attr('markerWidth', 3)
    .attr('markerHeight', 3)
    .attr('orient', 'auto')
    .append('svg:path')
    .attr('d', 'M0,-5L10,0L0,5')
    .attr('fill', '#000');

    this.svg.append('svg:defs').append('svg:marker')
    .attr('id', 'start-arrow')
    .attr('viewBox', '0 -5 10 10')
    .attr('refX', 4)
    .attr('markerWidth', 3)
    .attr('markerHeight', 3)
    .attr('orient', 'auto')
    .append('svg:path')
    .attr('d', 'M10,-5L0,0L10,5')
    .attr('fill', '#000');



// add the svg<g> element to group svg shapes together
    this.path = this.svg.append('svg:g').selectAll('path');
    this.circle = this.svg.append('svg:g').selectAll('g');

    this.linkword = this.svg.append('svg:g').selectAll('text');
    this.glossary = this.svg.append('svg:g').selectAll('rect');

    this.gText = this.svg.append('svg:g').selectAll('text')
    this.gImage = this.svg.append('svg:g').selectAll('img');
    ;


    var data = [1,2,3];

    var scale = d3.scaleLinear()
                  // .domain([d3.min(data), d3.max(data)])
                  .domain([1, d3.max(data)])
                  .range([0, 200]);
    var x_axis = d3.axisBottom(scale)
    .ticks(2, "f");

    this.svg.append("g")
       .attr("transform", "translate(500, 10)")
       .call(x_axis);

    this.circle1 = this.svg.append("circle")
    .attr('class', 'ball')
    .attr("cx", 500)
    .attr("cy", 10)
    .attr("r", 7)
    .style("fill", "purple");




// refresh after each mousedown and mouseup
    this.svg.on('mousedown', (dataItem, value, source) => this.mousedown(dataItem, value, source));
    this.restart();
    this.svg.on('mouseup', (dataItem) => this.mouseup(dataItem));
    this.restart();


    

  }

  mousedown(dataItem: any, value: any, source: any) {
    // when mouse down set this.svg as active
    this.svg.classed('active', true);
    

    if (this.svg.attr('hh')==='ff') {
      // if (this.mousedownNode === this.selectedNode || this.mousedownNode === null) {
        // if click on the same node once again or click on the background, then not zooming
         this.centered = null;
         this.selectedNode = null;
         this.centerx = this.width / 2;
         this.centery = this.height / 2;
         this.k = 1;


         
         this.svg.transition()
        .duration(750)
        .attr('transform', 'translate(' + this.width / 2 + ',' + this.height / 2 + ')scale(' + this.k + ')translate(' + -this.centerx + ',' + -this.centery + ')');
        //  console.log('this is my : ' + this.selectedNode );

        this.svg.selectAll('rect').attr('visibility','hidden');
      this.svg.selectAll('text.gText').attr('visibility','hidden');
         this.restart();
      // }
    }

    this.restart();
  }

  mouseup(source: any) {
    // when mouseup, set the svg background as inactive
    this.svg.classed('active', false);

    // clear mouse event vars
    this.mousedownNode = null;
    this.mouseupNode = null;
    this.mousedownLink = null;
    this.clickOnNode = false;

    this.svg.attr('hh','ff');


    // remove all white rectangulars when the scale is 1
    if (this.k === 1) {
      // this.svg.selectAll('rect').remove();
      // this.svg.selectAll('text.gText').remove();
      this.svg.selectAll('image.gImage').remove();

    }
}




wrap(text, width) {

  text.each(function() {
    // let r = 0;
    var text = d3.select(this),
      words = text.text().split('').reverse(),
      word,
      line = [],
      lineNumber = 0,
      
      // this should be set manually, otherwise problem when continuelly click on different nodes
      lineHeight = 5,
      // lineHeight = text.node().getBoundingClientRect().height,
      x = +text.attr('x'),
      y = +text.attr('y'),
      
      tspan = text.text(null).append('tspan').attr('x', x).attr('y', y);

      
    while (word = words.pop()) {
      line.push(word);
      const dash = lineNumber > 0 ? '-' : '';
      tspan.text(dash + line.join(''));
      if (tspan.node().getComputedTextLength() > width) {
        line.pop();
        tspan.text(line.join(''));
        line = [word];
        tspan = text.append('tspan').attr('x', x).attr('y', ++lineNumber * lineHeight + y).text(word);
      }
    }
    
  }
  );

}







// refresh function
  restart() {

    console.log('restart');

    // if(this.svg.select('circle.ball').attr('cx')==='500'){
    //   this.level = 1;
    // }
    // else if(this.svg.select('circle.ball').attr('cx')==='600'){
    //   this.level = 2;
    // }
    // else{
    //   this.level = 3;
    // }

    // this.svg.selectAll('ellipse.node').remove();

    // console.log('level'+this.level);
    // console.log('cx'+this.svg.select('circle.ball').attr('cx'));


    


    

// bind the paths with data
    this.path = this.path.data(this.links);
// bind the white rectangulars with data
    this.glossary = this.glossary.data(this.glossaries);

    this.gText = this.gText.data(this.gTexts);

    this.gImage = this.gImage.data(this.gTexts);

    this.path.exit().remove();



  // create paths
  this.path = this.path
  .enter()
  .append('svg:path')
  .attr('class', 'link')
  .attr('d', (d) => {
    const deltaX = d.target.x - d.source.x;
    const deltaY = d.target.y - d.source.y;
    const dist = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
    const normX = deltaX / dist;
    const normY = deltaY / dist;
    const xy = Math.abs(deltaX / deltaY);
    let sourcePadding = 8;

    let targetPadding = 0;


    if(d.target.reflexive){
      if (Math.abs(d.source.x - d.target.x) > 10*Math.abs(d.source.y - d.target.y) || Math.abs(d.source.x - d.target.x) === 10*Math.abs(d.source.y - d.target.y)){
      
        targetPadding = d.right ? 27-0.25*(2-xy) : 17-0.25*(2-xy);
        // targetPadding = d.right ? 27-800000*(2-xy)*Math.pow((dist/2310),5) : 17-400000*(2-xy)*Math.pow((dist/2310),5);
      }
  
      else if (Math.abs(d.source.x - d.target.x) > 3*Math.abs(d.source.y - d.target.y) || (Math.abs(d.source.x - d.target.x) === 3*Math.abs(d.source.y - d.target.y))){
        targetPadding = d.right ? 27-0.8*(2-xy) : 17-0.8*(2-xy);
      }
  
      else if (Math.abs(d.source.x - d.target.x) < 3*Math.abs(d.source.y - d.target.y)){     
        targetPadding = d.right ? 27-4*(2-xy) : 17-2*(2-xy);
      }
    }
    else{
      targetPadding = 8;
    }
    


    // const targetPadding = d.right ? 27-0.5*(2-xy) : 17-0.5*(2-xy);
    const sourceX = d.source.x + (sourcePadding * normX);
    const sourceY = d.source.y + (sourcePadding * normY);
    const targetX = d.target.x - (targetPadding * normX);
    const targetY = d.target.y - (targetPadding * normY);
// calculate the d attribute for path
    return `M${sourceX},${sourceY}L${targetX},${targetY}`;
  })
  // set arrow style
  .style('marker-start', (d) => d.left ? 'url(#start-arrow)' : '')
  .style('marker-end', (d) => d.right ? 'url(#end-arrow)' : '')
  .merge(this.path);


 



// bind the circle with data
  this.circle = this.circle.data(this.nodes, (d) => d.id);
  // create ellipses
  // this.circle.selectAll('ellipse')
  // .style('fill', (d) => (d === this.selectedNode) ? d3.rgb(this.colors(d.id)).brighter().toString() : this.colors(d.id))
  // .style('stroke', (d) => (d === this.selectedNode) ? 'black' : 'white');

  this.circle.exit().remove();

// for each ellipse create a g element
const g = this.circle.enter().append('svg:g');




// create ellipses
g.append('svg:ellipse')
.attr('class', 'node')
.attr('rx', 25)
.attr('ry', 15)
.attr('cx', (d) => d.x)
.attr('cy', (d) => d.y)
// .attr('fill',(d) => d.id===0? 'red': 'black')
.style('fill', (d) => 
{
  return 'grey';
  // if(this.level === 1){
  //   return 'green';
  // }
  // else{
  //   if(!d.reflexive){
  //     return 'black';
  //   }
  //   else {
  //     return 'green';
  //   }
  // }
}
// (this.level === 1) ? 'green' : this.colors(d.id)
)
.style('stroke', (d) => (!d.reflexive) ? 'black' : 'white')
.on('mousedown', (d) => {

  if(parseInt(this.svg.select('circle.ball').attr('cx'))===500){
    window.alert("Node locked");
  }
  else{
    // select node
  this.mousedownNode = d;
  this.selectedNode = (this.mousedownNode === this.selectedNode) ? null : this.mousedownNode;


  // if click on the same node twice, focus and zoom will be reset
  this.centerx = this.centered !== d ? d.x : this.width / 2;
  this.centery = this.centered !== d ? d.y : this.height / 2;
  this.k = this.centered !== d ? 3 : 1;
  this.centered = this.centered !== d ? d : null;
  this.clickOnNode = true;


  for (let i = 0; i < this.glossaries.length; i++) {
    this.glossaries[i].hidden = true;
    this.gTexts[i].hidden = true;
  }

  this.svg.selectAll('rect').remove();
  this.svg.selectAll('text.gText').remove();
  this.svg.selectAll('image.gImage').remove();


  if (this.k === 3) {
    this.glossaries[d.id].hidden = false;
    this.gTexts[d.id].hidden = false;
  }

  // important! don't delete this line
  this.restart();

  this.svg.transition()
  .duration(750)
  .attr('transform', 'translate(' + this.width * this.k / 2  + ',' + this.height * this.k / 2 + ')scale(' + this.k + ')translate(' + -this.centerx + ',' + -this.centery + ')');

  }
  
  });




// create texts
g.append('svg:text')
.attr('class', 'eText')
.attr('x', (d) => d.x)
.attr('y', (d) => d.y)
.attr('fill', 'white')
.attr('font-size', '5')
.attr('text-anchor', 'middle')
.text((d) => d.text);

this.circle = g.merge(this.circle);
this.circle.exit().remove();

this.glossary.exit().remove();


    this.glossary = this.glossary
      .enter()
      .append('svg:rect')
      // .append('svg:text')
      .attr('class', 'rect')
      .attr('x', (d) => d.target.x)
      .attr('y', (d) => d.target.y)
      .attr('fill', 'orange')
      .attr('width', '60')
      .attr('height', '80')
      // .attr('font-size', '5')
      // .attr('text-anchor', 'middle')
      // .text((d) => d.text)
      .attr('visibility', (d) => d.hidden ? 'hidden' : 'visible')
      .attr('stroke', 'black')
      // .raise()
      // .attr('z-index', 2)
      ;
      
      this.gText.exit().remove();

      this.gImage.exit().remove();




this.gText = this.gText
.enter()
.append('svg:text')
.attr('class', 'gText')
.attr('x', (d) => d.target.x+10)
.attr('y', (d) => d.target.y+10)
.attr('fill', 'black')
.attr('font-size', '4')
.attr('text-anchor', 'left')
.attr('visibility', (d) => d.hidden ? 'hidden' : 'visible')
.text((d) => d.text)
.call(this.wrap,40)
;

this.gImage = this.gImage
.enter()
.append('svg:image')
.attr('class', 'gImage')
.attr('x', (d) => d.target.x+10)
.attr('y', (d) => d.target.y+60)
.attr('xlink:href', 'assets/icon.jpg')
.attr('width', 20)
.attr('height', 15)
.attr('visibility', (d) => d.hidden ? 'hidden' : 'visible')
;








// create link words
this.linkword = this.linkword.data(this.linkwords, (d) => d.id);
this.linkword.exit().remove();
// const g1 = this.linkword.enter().append('svg:g');
this.linkword = this.linkword.enter()
.append('svg:text')
.attr('class', 'text')
.attr('x', (d) => d.x)
.attr('y', (d) => d.y)
.attr('fill', 'red')
.attr('font-size', '5')
.attr('text-anchor', 'middle')
.text((d) => d.text);





    // var data = [1,2,3];

    // var scale = d3.scaleLinear()
    //               // .domain([d3.min(data), d3.max(data)])
    //               .domain([1, d3.max(data)])
    //               .range([0, 200]);
    // var x_axis = d3.axisBottom(scale)
    // .ticks(2, "f");

    // this.svg.append("g")
    //    .attr("transform", "translate(500, 10)")
    //    .call(x_axis);

    // var circle = this.svg.append("circle")
    // .attr('class', 'ball')
    // .attr("cx", 500)
    // .attr("cy", 10)
    // .attr("r", 7)
    // .style("fill", "purple");

    this.circle1.call(d3.drag()
     .on('start', function(d) {
      d3.event.sourceEvent.stopPropagation();
      d3.select(this)
        .classed("dragging", true);

        // d3.select(this).classed("dragging", true);
     })
     .on('drag', function(d) {
      d3.select(this).attr("cx", 
      (d)=>{
        // console.log(this);
        if(d3.event.x<550){
          return 500;
        }
        else if(d3.event.x<=650){
          return 600;
        }
        else{
          return 700;
        }
      })
      d3.select(this).attr("cy", 10);

      var cx = parseInt(d3.select(this).attr('cx'));
        if(cx===500){
          d3.select('svg').selectAll('rect').attr('visibility', 'hidden');
            d3.select('svg').selectAll('text.gText').attr('visibility', 'hidden');
          d3.select('svg').selectAll('ellipse.node').style('fill','grey')
          .on('mousedown', (d)=> window.alert("Node locked"));
        }
        else if(cx===600){

          // d3.select('svg').attr('background-color')
          d3.select('svg').attr('hh', 'ff');

          d3.select('svg').selectAll('ellipse.node').style('fill','green');
          d3.select('svg').selectAll('ellipse.node').on('mousedown', (d)=>{
            console.log(d['id']);
            var id = d['id'];

            // d3.select('svg').selectAll('rect').attr('visibility', 'hidden');
            // d3.select('svg').selectAll('text.gText').attr('visibility', 'hidden');
            // first click

            if(d3.select('svg').selectAll('rect').filter(function(a,i){
              return i===id}).attr('visibility')==='hidden'){
                d3.select('svg').attr('hh', 'aa');
              }
              else{
                d3.select('svg').attr('hh', 'ff');
              }



            d3.select('svg').selectAll('rect').filter(function(a,i){
              return i===id}).attr('visibility', 
              d3.select('svg').selectAll('rect').filter(function(a,i){
                return i===id}).attr('visibility')==='hidden'?'visible':'hidden'
              );
            d3.select('svg').selectAll('text.gText').filter(function(a,i){
                return i===id}).attr('visibility', 
                d3.select('svg').selectAll('rect').filter(function(a,i){
                  return i===id}).attr('visibility')==='hidden'?'hidden':'visible'              
              );

              d3.select('svg').selectAll('rect').filter(function(a,i){
                return i!==id}).attr('visibility', 
                'hidden'
                );
              d3.select('svg').selectAll('text.gText').filter(function(a,i){
                  return i!==id}).attr('visibility', 
                  'hidden'
                  );

        var k = (d3.select('svg').selectAll('rect').filter(function(a,i){
          return i===id}).attr('visibility')==='hidden')?1:3;

          var x = (d3.select('svg').selectAll('rect').filter(function(a,i){
            return i===id}).attr('visibility')==='hidden')?620:d['x'];

          var y = (d3.select('svg').selectAll('rect').filter(function(a,i){
              return i===id}).attr('visibility')==='hidden')?285:d['y'];

         d3.select('svg').transition()
        .duration(750)
        .attr('transform', 'translate(' + 1240 * k / 2  + ',' + 570 * k / 2 + ')scale(' + k + ')translate(' + -x + ',' + -y + ')');


       })
      
      
      //  d3.select('svg').on('mousedown', (d)=>{
      //    if(!clickOnNode){
      //     d3.select('svg').transition()
      //     .duration(750)
      //     .attr('transform', 'translate(' + 1240 / 2 + ',' + 570 / 2 + ')scale(' + 1 + ')translate(' + -1240/2 + ',' + -570/2 + ')');
      //    }
      // })
      // ;


          d3.select('svg').selectAll('ellipse.node').filter(function(d, i){
            return i>=7}).style('fill','grey');
          d3.select('svg').selectAll('ellipse.node').filter(function(d, i){
              return i>=7}).on('mousedown', (d)=> window.alert("Node locked"))
        }
        else {


          d3.select('svg').attr('hh', 'ff');

          d3.select('svg').selectAll('rect').attr('visibility', 'hidden');
            d3.select('svg').selectAll('text.gText').attr('visibility', 'hidden');
          d3.select('svg').selectAll('ellipse.node').style('fill','green').on('mousedown', 
          (d)=> {           
            
            
            var id = d['id'];

            if(d3.select('svg').selectAll('rect').filter(function(a,i){
              return i===id}).attr('visibility')==='hidden'){
                d3.select('svg').attr('hh', 'aa');
              }
              else{
                d3.select('svg').attr('hh', 'ff');
              }


          d3.select('svg').selectAll('rect').filter(function(a,i){
            return i===id}).attr('visibility', 
            d3.select('svg').selectAll('rect').filter(function(a,i){
              return i===id}).attr('visibility')==='hidden'?'visible':'hidden'
            );
          d3.select('svg').selectAll('text.gText').filter(function(a,i){
              return i===id}).attr('visibility', 
              d3.select('svg').selectAll('rect').filter(function(a,i){
                return i===id}).attr('visibility')==='hidden'?'hidden':'visible'              
            );

            d3.select('svg').selectAll('rect').filter(function(a,i){
              return i!==id}).attr('visibility', 
              'hidden'
              );
              d3.select('svg').selectAll('text.gText').filter(function(a,i){
                return i!==id}).attr('visibility', 
                'hidden'
                );


                var k = (d3.select('svg').selectAll('rect').filter(function(a,i){
                  return i===id}).attr('visibility')==='hidden')?1:3;
        
                  var x = (d3.select('svg').selectAll('rect').filter(function(a,i){
                    return i===id}).attr('visibility')==='hidden')?620:d['x'];
        
                  var y = (d3.select('svg').selectAll('rect').filter(function(a,i){
                      return i===id}).attr('visibility')==='hidden')?285:d['y'];
        
                 d3.select('svg').transition()
                .duration(750)
                .attr('transform', 'translate(' + 1240 * k / 2  + ',' + 570 * k / 2 + ')scale(' + k + ')translate(' + -x + ',' + -y + ')');
            
            });
        }
      
     })
     .on('end', function(d) {
         d3.select(this).classed("dragging", false);
        //  d3.select('svg').selectAll('ellipse.node').style('fill', (d)=> {
        //   //  console.log(d3.select('svg').selectAll('ellipse.node'));
        //    var test = d3.select('svg').selectAll('ellipse.node');
        //    console.log(test.attr('style'));
        //    return 'red'; 
        //  })
        
        
         //  d3.selectAll('text.eText').attr('fill',(d)=>{return 'black'});
     })    
)
// .call(this.update(this.svg.select('circle.ball').attr('cx')))
// .call(this.restart())
;


console.log(this.level);
console.log(parseInt(this.svg.select('circle.ball').attr('cx')));

// if(this.level!==(parseInt(this.svg.select('circle.ball').attr('cx'))/100)-4){
//   console.log('!==');
//   this.level = (parseInt(this.svg.select('circle.ball').attr('cx'))/100)-4;
//   this.restart();
// }

// console.log(this.svg.select('circle.ball').attr('cx'));

// if(this.svg.select('circle.ball').attr('cx')==='500'){
//   this.level = 1;
// }
// else if(this.svg.select('circle.ball').attr('cx')==='600'){
//   this.level = 2;
// }
// else{
//   this.level = 3;
// }


for (let i = 0; i < this.glossaries.length; i++) {
  this.glossaries[i].hidden = true;
  this.gTexts[i].hidden = true;
}


  }
}

