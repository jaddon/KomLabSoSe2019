import { Component, OnInit } from '@angular/core';
import * as d3 from 'd3';
import {style} from '@angular/animations';

@Component({
  selector: 'app-slider-test',
  templateUrl: './slider-test.component.html',
  styleUrls: ['./slider-test.component.css']
})
export class SliderTestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
