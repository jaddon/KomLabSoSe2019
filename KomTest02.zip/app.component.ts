import { Component, ElementRef, ViewChild } from '@angular/core';
import * as d3 from 'd3';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'KomTest';

  @ViewChild('graphContainer') graphContainer: ElementRef;

  width = 1240;
  height = 570;
  k = 1;
  colors = d3.scaleOrdinal(d3.schemeCategory10);
  clickOnNode = false;
  svg: any;
  circle: any;
  path: any;
  centered: any;
  centerx: any;
  centery: any;

  selectedNode = null;
  selectedLink = null;
  mousedownLink = null;
  mousedownNode = null;
  mouseupNode = null;

  //store the nodes
  nodes = [
    { id: 0, text: 'java', x: 300, y: 70, reflexive: false },
    { id: 1, text: 'computer science', x: 150, y: 100, reflexive: false },
    { id: 2, text: 'program', x: 250, y: 300, reflexive: false },
    { id: 3, text: 'variable', x: 350, y: 275, reflexive: false },
    { id: 4, text: 'primitive type', x: 430, y: 240, reflexive: false },
    { id: 5, text: 'object', x: 520, y: 180, reflexive: false },
    { id: 6, text: 'class', x: 500, y: 120, reflexive: false },
    { id: 7, text: 'method', x: 520, y: 50, reflexive: false },
  ];

  //store the links
  links = [
    { source: this.nodes[0], target: this.nodes[1], left: false, right: true },
    { source: this.nodes[0], target: this.nodes[2], left: false, right: true },
    { source: this.nodes[0], target: this.nodes[3], left: false, right: true },
    { source: this.nodes[0], target: this.nodes[4], left: false, right: true },
    { source: this.nodes[0], target: this.nodes[5], left: false, right: true },
    { source: this.nodes[0], target: this.nodes[6], left: false, right: true },
    { source: this.nodes[0], target: this.nodes[7], left: false, right: true },
  ];


  ngAfterContentInit() {
    const rect = this.graphContainer.nativeElement.getBoundingClientRect();
    console.log(rect.width, rect.height);

    // this.width = rect.width;
    // this.height = rect.height;



    this.svg = d3.select('#graphContainer')
    .attr('oncontextmenu', 'return false;')
    .attr('width', this.width)
    .attr('height', this.height);



  //arrow styles
  this.svg.append('svg:defs').append('svg:marker')
    .attr('id', 'end-arrow')
    .attr('viewBox', '0 -5 10 10')
    .attr('refX', 6)
    .attr('markerWidth', 3)
    .attr('markerHeight', 3)
    .attr('orient', 'auto')
    .append('svg:path')
    .attr('d', 'M0,-5L10,0L0,5')
    .attr('fill', '#000');

  this.svg.append('svg:defs').append('svg:marker')
    .attr('id', 'start-arrow')
    .attr('viewBox', '0 -5 10 10')
    .attr('refX', 4)
    .attr('markerWidth', 3)
    .attr('markerHeight', 3)
    .attr('orient', 'auto')
    .append('svg:path')
    .attr('d', 'M10,-5L0,0L10,5')
    .attr('fill', '#000');



    this.path = this.svg.append('svg:g').selectAll('path');
    this.circle = this.svg.append('svg:g').selectAll('g');




 this.svg.on('mousedown', (dataItem, value, source) => this.mousedown(dataItem, value, source))
 .on('mouseup', (dataItem) => this.mouseup(dataItem));
 this.restart();
                  

  }

  mousedown(dataItem: any, value: any, source: any) {
    // because :active only works in WebKit?
    this.svg.classed('active', true);

    if(this.clickOnNode===false){
      if(this.mousedownNode === this.selectedNode||this.mousedownNode===null){
         this.centered = null;
         this.centerx = this.width/2;
         this.centery = this.height/2;
         this.k = 1;

        this.svg.transition()
        .duration(750)
        .attr("transform", "translate(" + this.width / 2 + "," + this.height / 2 + ")scale(" + this.k + ")translate(" + -this.centerx + "," + -this.centery + ")");
      }
    }

    console.log('down');
    // console.log(this.clickOnNode);
    // console.log(this.mousedownNode);
    // console.log(this.selectedNode);

    this.restart();
  }

  mouseup(source: any) {
    // because :active only works in WebKit?
    this.svg.classed('active', false);

    // clear mouse event vars
    this.mousedownNode = null;
    this.mouseupNode = null;
    this.mousedownLink = null;

    console.log('up');
    
    this.clickOnNode = false;
}

  restart(){
    
    this.path = this.path.data(this.links);

    this.path.style('marker-start', (d) => d.left ? 'url(#start-arrow)' : '')
      .style('marker-end', (d) => d.right ? 'url(#end-arrow)' : '');



  //create paths
  this.path = this.path
  .enter()
  .append('svg:path')
  .attr('class', 'link')
  .attr('d', (d) => {
    const deltaX = d.target.x - d.source.x;
    const deltaY = d.target.y - d.source.y;
    const dist = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
    const normX = deltaX / dist;
    const normY = deltaY / dist;
    const sourcePadding = d.left ? 17 : 12;
    const targetPadding = d.right ? 17 : 12;
    const sourceX = d.source.x + (sourcePadding * normX);
    const sourceY = d.source.y + (sourcePadding * normY);
    const targetX = d.target.x - (targetPadding * normX);
    const targetY = d.target.y - (targetPadding * normY);
//calculate the d attribute for path
    return `M${sourceX},${sourceY}L${targetX},${targetY}`;
  })
  //set arrow style
  .style('marker-start', (d) => d.left ? 'url(#start-arrow)' : '')
  .style('marker-end', (d) => d.right ? 'url(#end-arrow)' : '');



  this.circle = this.circle.data(this.nodes, (d) => d.id);

  this.circle.selectAll('ellipse')
  .style('fill', (d) => (d === this.selectedNode) ? d3.rgb(this.colors(d.id)).brighter().toString() : this.colors(d.id))
  .style('stroke', (d) => (d === this.selectedNode) ? 'black' : 'white');

  const g = this.circle.enter().append('svg:g');

//create ellipses
g.append('svg:ellipse')
.attr('class', 'node')
.attr('rx', 25)
.attr('ry',15)
.attr('cx',(d) => d.x)
.attr('cy',(d) => d.y)
// .attr('fill',(d) => d.id===0? 'red': 'black')
.style('fill', (d) => (d === this.selectedNode) ? d3.rgb(this.colors(d.id)).brighter().toString() : this.colors(d.id))
.style('stroke', (d) => (d === this.selectedNode) ? 'black' : 'white')
.on('mousedown', (d) => {

  // select node
  this.mousedownNode = d;
  this.selectedNode = (this.mousedownNode === this.selectedNode) ? null : this.mousedownNode;

  // console.log('before'+this.centered);

  this.centerx = this.centered!==d?d.x:this.width/2;
  this.centery = this.centered!==d?d.y:this.height/2;
  this.k = this.centered!==d?4:1;
  this.centered = this.centered!==d?d:null;
  this.clickOnNode = true;

// console.log('after'+this.centered);
// console.log(d);
// console.log(this.k);


  this.svg.transition()
  .duration(1000)
  .attr("transform", "translate(" + this.width*this.k / 2  + "," + this.height*this.k / 2 + ")scale(" + this.k + ")translate(" + -this.centerx + "," + -this.centery + ")");
  // .attr("transform", "translate(" + (this.width / 2 -this.centerx) + "," + (this.height / 2 -this.centery) + ")scale(" + this.k + ")");
  // .attr("transform", "translate(" + this.width / 2 + "," + this.height / 2 + ")scale(" + this.k + ")");
  })

  console.log(this.centerx);

;


console.log(this.selectedNode);



//create texts
g.append('svg:text')
.attr('class', 'text')
.attr('x',(d) => d.x)
.attr('y',(d) => d.y)
.attr('fill','white')
.attr('font-size','5')
.attr('text-anchor','middle')
.text((d)=>d.text);

// console.log(this.mousedownNode);
// console.log(this.selectedNode);


// console.log(this.centered);
// console.log(this.centerx);
// console.log(this.centery);
// console.log(this.k);
  }
}
