import { NgModule } from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
// import page
import { Page1Component } from './page1/page1.component';
import { HomeComponent } from './home/home.component';
import {SingleChoiceComponent} from './test/singleChoice/singleChoice.component';
// Create Path Here
const routes: Routes = [
    {path: '', component: HomeComponent},
    {path: 'home', component: HomeComponent},
    {path: 'page1', component: Page1Component},
    {path: 'test/singleChoice', component: SingleChoiceComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes) ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
