export class Question {
  question: string;
  items: string[];
  userchoice: string;
  rightanswer: string;
  explanation: string;
}
